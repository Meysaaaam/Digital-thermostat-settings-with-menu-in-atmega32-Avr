#include <mega32.h>
#include <delay.h>
#include <alcd.h>
#include <stdio.h>
#include "define.h"
#include "mcu_init.h"

int32_t TEMP;
uint8_t H,L;
int8_t str[17];


unsigned int adc_data;
// Voltage Reference: AVCC pin
//#define ADC_VREF_TYPE ((0<<REFS1) | (1<<REFS0) | (0<<ADLAR))

// ADC interrupt service routine
interrupt [ADC_INT] void adc_isr(void)
{
// Read the AD conversion result
adc_data=ADCW;
}

// Read the AD conversion result
// with noise canceling
unsigned int read_adc(unsigned char adc_input)
{
ADMUX=adc_input | ADC_VREF_TYPE;
// Delay needed for the stabilization of the ADC input voltage
delay_us(10);
#asm
    in   r30,mcucr
    cbr  r30,__sm_mask
    sbr  r30,__se_bit | __sm_adc_noise_red
    out  mcucr,r30
    sleep
    cbr  r30,__se_bit
    out  mcucr,r30
#endasm
return adc_data;
}

void main(void)
{

    mcu_init();
    while (1)
    {
        switch(state){
            case menu1:
                lcd_gotoxy(0,0);
                lcd_puts("1-Temp ");
                lcd_gotoxy(0,1);
                lcd_puts("2-Set  ");
                if(KEY_1){
                    Debounce_key;
                    while(KEY_1);
                    lcd_clear();
                    state=menu1_s;}
                    
                if(KEY_2){
                    Debounce_key;
                    while(KEY_1);
                    lcd_clear();
                    state=menu2_s;}
                break;
                
            case menu2_s:
                sprintf(str,"H=%02d  \xdf C  \X5E",H);
                lcd_gotoxy(0,0);
                lcd_puts(str);
                sprintf(str,"L=%02d  \xdf C  \X5E",L);
                lcd_gotoxy(0,1);
                lcd_puts(str);
                if(KEY_1){
                    Debounce_key;
                    H++;
                    H=H>99 ? 0:H;} 
                    
                if(KEY_2){
                    Debounce_key;
                    L++;
                    L=L>99 ? 0:L;}
                    
                if(KEY_Back){
                    Debounce_key;
                    while(KEY_Back);
                    lcd_clear();
                    state=menu1;}
                break;
                
            case menu1_s:   
                    TEMP=read_adc(ADC_A);
                    TEMP=TEMP*500/1023;
                    sprintf(str,"Temp=%0.2f \xdf C",TEMP);
                    lcd_gotoxy(0,0);
                    lcd_puts(str);
                    sprintf(str,"H=%02d",H);
                    lcd_gotoxy(0,1);
                    lcd_puts(str);
                    sprintf(str,"L=%02d",L);
                    lcd_gotoxy(10,1);
                    lcd_puts(str);
                    if(TEMP > H && H!=0){
                        Relay_1=ON;
                        Relay_2=OFF;
                    }
                    
                    else{
                        Relay_1=OFF;
                    }
                    
                    if(TEMP < L){
                        Relay_1=OFF;
                        Relay_2=ON;
                    }
                    
                    else{
                        Relay_2=OFF;
                    }
                    
                    if(KEY_Back){
                        Debounce_key;
                        while(KEY_Back);
                        Relay_1=OFF;
                        Relay_2=OFF;
                        lcd_clear();
                        state=menu1;}
                 break; 
        }
}
}
