#ifndef _DEFINE_H
#define _DEFINE_H

#include <mega32.h>
#include <alcd.h>
#include <stdio.h>
#include <delay.h>

#define Relay_1         PORTC.0     
#define Relay_2         PORTC.1     
#define KEY_1           PIND.0==0
#define KEY_2           PIND.1==0
#define KEY_Back        PIND.2==0


#define ON             1
#define OFF            0
#define Debounce_key   delay_ms(200)


#define ADC_VREF       5

#define ADC_A		   0
#define ADC_B		   1
#define ADC_C		   2
#define ADC_D		   3
#define ADC_E		   4
#define ADC_F		   5
#define ADC_G		   6
#define ADC_H		   7


typedef  char           int8_t;
typedef  unsigned char  uint8_t;
typedef  int            int16_t;
typedef  unsigned int   uint16_t;
typedef  float          int32_t;



enum e_type{
    menu1,
    menu1_s,
    menu2_s,}state;

void mcu_init(void);

#endif 